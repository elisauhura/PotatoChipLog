//
//  TestBench.m
//  TestBench
//
//  Created by Elisa Silva on 07/10/21.
//
//  Copyright 2021 Elisa Silva
//  
//  Permission is hereby granted, free of charge, to any person obtaining a 
//  copy of this software and associated documentation files (the "Software"), 
//  to deal in the Software without restriction, including without limitation 
//  the rights to use, copy, modify, merge, publish, distribute, sublicense, 
//  and/or sell copies of the Software, and to permit persons to whom the Software 
//  is furnished to do so, subject to the following conditions:
//  
//  The above copyright notice and this permission notice shall be included in 
//  all copies or substantial portions of the Software.
//  
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS 
//  OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
//  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN 
//  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

#import <XCTest/XCTest.h>

#import "UHRTestBench.h"
#import "UHRTestBenchScript.h"

@interface UHRTestBench ()

@property (nonatomic) id<UHRModuleInterface>module;
@property (nonatomic) UHRTestBenchScript *script;

@end

@implementation UHRTestBench

- (instancetype)initWithModule:(id<UHRModuleInterface>)module withScript:(UHRTestBenchScript *)script {
    self = [super init];
    if(self != nil) {
        _module = module;
        _script = script;
        
        [_script useXCTestIntegration:YES];
    }
    return self;
}

- (BOOL)runTestBenchUpToTime:(UHRTimeUnit)time {
    UHRTimeUnit simulationTime = 0;
    while(simulationTime < time) {
        [_module pokeSignal:[_module clockSignal] withValue:1];
        [_script applyOnRiseChangesToModule:_module atTime:simulationTime];
        [_module evaluateStateAtTime:10+simulationTime*10];
        [_script checkOnHighContrainsForModule:_module atTime:simulationTime];
        
        [_module pokeSignal:[_module clockSignal] withValue:0];
        [_script applyOnFallChangesToModule:_module atTime:simulationTime];
        [_module evaluateStateAtTime:15+simulationTime*10];
        [_script checkOnLowContrainsForModule:_module atTime:simulationTime];
        
        [_script callCallbackWithModule:_module atTime:simulationTime];
        
        if([_script passScriptForModule:_module atTime:simulationTime]) {
            break;
        }
        
        simulationTime++;
    }
    return simulationTime < time;
}

@end
