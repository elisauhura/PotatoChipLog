//
//  UHRTestBenchScriptTests.m
//  TestBenchTests
//
//  Created by Elisa Silva on 07/10/21.
//
//  Copyright 2021 Elisa Silva
//  
//  Permission is hereby granted, free of charge, to any person obtaining a 
//  copy of this software and associated documentation files (the "Software"), 
//  to deal in the Software without restriction, including without limitation 
//  the rights to use, copy, modify, merge, publish, distribute, sublicense, 
//  and/or sell copies of the Software, and to permit persons to whom the Software 
//  is furnished to do so, subject to the following conditions:
//  
//  The above copyright notice and this permission notice shall be included in 
//  all copies or substantial portions of the Software.
//  
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS 
//  OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
//  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN 
//  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

#import <XCTest/XCTest.h>
#import <OCMock/OCMock.h>

#import "UHRTestBenchScript.h"

static BOOL callbackCalled = NO;

@interface UHRTestBenchScriptTests : XCTestCase

@property UHRTestBenchScript *script;

@end

@implementation UHRTestBenchScriptTests

- (void)setUp {
    callbackCalled = NO;
    _script = [UHRTestBenchScript scriptFromDictionary:@{
        @(1): @{
            @"applyOnRise": @[
                @(3), @(4),
                @(0), @(1)
            ],
            @"applyOnFall": @[
                @(4), @(1),
                @(99), @(1)
            ]
        },
        @(5): @{
            @"checkOnHigh": @[
                @(3), @(4),
                @(0), @(1)
            ],
            @"checkOnLow": @[
                @(4), @(1),
                @(99), @(1)
            ]
        },
        @(10): @{
            @"callback": ^BOOL(id module, UInt32 time) {
                XCTAssert(time == 10);
                callbackCalled = YES;
                return FALSE;
            },
            @"pass": @{}
        }
    }];
}

- (void)testApply {
    id mockedModule = OCMProtocolMock(@protocol(UHRModuleInterface));
    OCMStub([mockedModule signalNames]).andReturn(nil);
    
    [_script applyOnRiseChangesToModule:mockedModule atTime:1];
    [_script applyOnFallChangesToModule:mockedModule atTime:1];
    
    OCMVerify([mockedModule pokeSignal:3 withValue:4]);
    OCMVerify([mockedModule pokeSignal:0 withValue:1]);
    OCMVerify([mockedModule pokeSignal:4 withValue:1]);
    OCMVerify([mockedModule pokeSignal:99 withValue:1]);
}

- (void)testCheck {
    id mockedModule = OCMProtocolMock(@protocol(UHRModuleInterface));
    
    OCMStub([mockedModule peekSignal:3]).andReturn(4);
    OCMStub([mockedModule peekSignal:0]).andReturn(1);
    OCMStub([mockedModule peekSignal:4]).andReturn(1);
    OCMStub([mockedModule peekSignal:99]).andReturn(1);
    
    XCTAssertTrue([_script checkOnHighContrainsForModule:mockedModule atTime:5]);
    XCTAssertTrue([_script checkOnLowContrainsForModule:mockedModule atTime:5]);
}

- (void)testCheckFailure {
    id mockedModule = OCMProtocolMock(@protocol(UHRModuleInterface));
    
    OCMStub([mockedModule peekSignal:3]).andReturn(4);
    OCMStub([mockedModule peekSignal:0]).andReturn(2);
    OCMStub([mockedModule peekSignal:4]).andReturn(1);
    OCMStub([mockedModule peekSignal:99]).andReturn(3);
    
    XCTAssertFalse([_script checkOnHighContrainsForModule:mockedModule atTime:5]);
    XCTAssertFalse([_script checkOnLowContrainsForModule:mockedModule atTime:5]);
}

- (void)testUseXCTestIntegration {
    [_script useXCTestIntegration:YES];
    
    id mockedModule = OCMProtocolMock(@protocol(UHRModuleInterface));
    
    OCMStub([mockedModule peekSignal:3]).andReturn(4);
    OCMStub([mockedModule peekSignal:0]).andReturn(2);
    OCMStub([mockedModule peekSignal:4]).andReturn(1);
    OCMStub([mockedModule peekSignal:99]).andReturn(3);
    
    XCTExpectedFailureOptions *options = [[XCTExpectedFailureOptions alloc] init];
    options.strict = YES;
    options.issueMatcher = ^ BOOL(XCTIssue *issue) {
        if(issue.type == XCTIssueTypeAssertionFailure &&
           ([issue.compactDescription isEqualTo:@"failed - checkOnHigh failed @5; signal (null)(0) returned 2 when expecting 1."] ||
           [issue.compactDescription isEqualTo:@"failed - checkOnLow failed @5; signal (null)(99) returned 3 when expecting 1."])) {
            return YES;
        }
        return NO;
    };
    
    XCTExpectFailureWithOptions(@"Must fail when running with XCTest", options);
    
    XCTAssertTrue([_script checkOnHighContrainsForModule:mockedModule atTime:5]);
    XCTAssertTrue([_script checkOnLowContrainsForModule:mockedModule atTime:5]);
}

- (void)testPass {
    XCTAssertTrue([_script passScriptForModule:nil atTime:10]);
    XCTAssertFalse([_script passScriptForModule:nil atTime:5]);
}

- (void)testCallback {
    XCTAssert([_script callCallbackWithModule:nil atTime:5]);
    XCTAssertFalse(callbackCalled);
    XCTAssertFalse([_script callCallbackWithModule:nil atTime:10]);
    XCTAssert(callbackCalled);
}


@end
