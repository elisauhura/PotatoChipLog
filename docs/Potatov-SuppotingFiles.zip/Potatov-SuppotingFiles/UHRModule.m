//
//  UHRModule.m
//  Peeler
//
//  Created by Elisa Silva on 26/10/21.
//
//  Copyright 2021 Elisa Silva
//  
//  Permission is hereby granted, free of charge, to any person obtaining a 
//  copy of this software and associated documentation files (the "Software"), 
//  to deal in the Software without restriction, including without limitation 
//  the rights to use, copy, modify, merge, publish, distribute, sublicense, 
//  and/or sell copies of the Software, and to permit persons to whom the Software 
//  is furnished to do so, subject to the following conditions:
//  
//  The above copyright notice and this permission notice shall be included in 
//  all copies or substantial portions of the Software.
//  
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS 
//  OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
//  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN 
//  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

#import "UHRModule.h"
#import "UHRModule_Private.h"

@implementation UHRModule

- (instancetype)init
{
    self = [super init];
    if (self) {
        _module = NULL;
    }
    return self;
}

- (void)dealloc {
    if(_module != NULL) {
        _destroy(_module);
    }
}

- (void)pokeSignal:(UHREnum)signal withValue:(UHRWord)value {
    if(_module != NULL) {
        _poke(_module, signal, value);
    }
}

- (UHRWord)peekSignal:(UHREnum)signal {
    UHRWord ret = 0;
    if(_module != NULL) {
        ret = _peek(_module, signal);
    }
    return ret;
}

- (void)evaluateStateAtTime:(UHRTimeUnit)time {
    if(_module != NULL) {
        _eval(_module, time);
    }
}

@end
