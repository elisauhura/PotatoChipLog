//
//  UHRModuleDispatch.h
//  Peeler
//
//  Created by Elisa Silva on 11/10/21.
//
//  Copyright 2021 Elisa Silva
//  
//  Permission is hereby granted, free of charge, to any person obtaining a 
//  copy of this software and associated documentation files (the "Software"), 
//  to deal in the Software without restriction, including without limitation 
//  the rights to use, copy, modify, merge, publish, distribute, sublicense, 
//  and/or sell copies of the Software, and to permit persons to whom the Software 
//  is furnished to do so, subject to the following conditions:
//  
//  The above copyright notice and this permission notice shall be included in 
//  all copies or substantial portions of the Software.
//  
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS 
//  OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
//  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN 
//  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

#pragma once

enum UHRModuleDispatchRequest {
    UHRModuleDispatchRequestNothing = 0,
    UHRModuleDispatchRequestMemoryInterfaceGetDelayFor = 1,
    UHRModuleDispatchRequestMemoryInterfaceDoOperation = 2,
};

typedef unsigned int (*UHRModuleDispatchHandler) (unsigned int source, unsigned int request, unsigned int arg0, unsigned int arg1, unsigned int arg2, void * context);

unsigned int UHRModuleDispatch(unsigned int source, unsigned int request, unsigned int arg0, unsigned int arg1, unsigned int arg2);

unsigned int UHRModuleDispatchRegisterHandlerForID(unsigned int id, UHRModuleDispatchHandler handler,void * context);

unsigned int UHRModuleDispatchRemoveHandlerForID(unsigned int id);

extern const unsigned int UHRModuleDisptachDefaultID;


